package com.donamancio.holamundo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HolaMundo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.hola_mundo);
    }
}